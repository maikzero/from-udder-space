export enum FUS_Color {
    RED = "red",
    BLUE = "blue",
    GREEN = "green"
}